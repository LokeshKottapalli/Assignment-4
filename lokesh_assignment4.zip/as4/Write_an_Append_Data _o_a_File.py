data = input("Enter some text to write into the file: ")

file = open("output.txt", "w")
file.write(data + "\n")
file.close()

more_data = input("Enter additional text to append: ")

file = open("output.txt", "a")
file.write(more_data + "\n")
file.close()

file = open("output.txt", "r")
print("\nFinal content of the file:")
print(file.read())
file.close()
try:
    with open("sample.txt") as file:
        line1 = file.readline()
        line2 = file.readline()
        print("Reading file content...")
        print(f"Line 1:{line1}")
        print(f"Line 2:{line2}")



    file.close()

except FileNotFoundError:
    print("Error: The file 'sample.txt' does not exist.")